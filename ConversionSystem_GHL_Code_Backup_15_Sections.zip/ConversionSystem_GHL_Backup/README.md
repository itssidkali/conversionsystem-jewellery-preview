# ConversionSystem™ — GHL Code Backup

This folder is an archival backup of 15 individual custom-code sections/pages shared in the conversation.

## Contents

1. `01-announcement-header.html` — Announcement/header strip
2. `02-jewellery-hero.html` — Jewellery hero section
3. `03-problems.html` — Problems section
4. `04-the-gap.html` — The Gap section
5. `05-clarity.html` — From Guessing to Clarity
6. `06-toolkit.html` — Toolkit section
7. `07-30-day-game-plan.html` — 30-Day Game Plan
8. `08-diagnosis.html` — Diagnosis section
9. `09-final-close.html` — Final Close section
10. `10-who-this-is-for.html` — Who This Is Actually For
11. `11-offer-value-stack.html` — Offer / Value Stack
12. `12-faq.html` — FAQ section
13. `13-final-purchase-close.html` — Final Purchase Close
14. `14-enrollment-checkout.html` — Enrollment / Razorpay checkout custom code
15. `15-thank-you-page.html` — Thank-you page code

## Important

- These are separate GHL custom-code blocks/pages, not a combined or independently deployed website.
- The 14 uploaded source files were copied byte-for-byte; only their backup filenames/extensions were changed. The announcement header was saved from the code pasted inline in chat.
- This backup process did not edit payment endpoints, form IDs, Razorpay checkout logic, or verification logic.
- Keep this repository **Private** on GitHub. Never commit Razorpay Key Secret, passwords, API secrets, private tokens, or `.env` files. If any such values exist in a source file, remove secrets from the GitHub copy and store them only in secure environment variables. Do not publish this backup as a public repository.
- Store a second copy on your own computer or a separate private drive as well.

## Upload to GitHub

1. Extract the ZIP on your computer.
2. Open your own GitHub account and create a new repository named `ConversionSystem-GHL-Backup`.
3. Set repository visibility to **Private**.
4. Upload the `Sections` folder and this `README.md` (GitHub web upload allows selecting multiple files; if uploading nested files is awkward, open `Sections` and upload the 15 files there).
5. Commit changes. Confirm the repository still shows **Private**.

## Before relying on this backup

Open each important file and compare it with the current GHL Custom HTML/JavaScript block. In particular, verify checkout endpoints and payment verification source against the live version before restoring anything. This ZIP is a copy of code provided in chat; it does not include GHL CRM records, workflows, funnels/settings, domain DNS records, external assets not embedded in the code, or Vercel project settings.
